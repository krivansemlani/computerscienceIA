

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Create Revision Question')); ?>

        </h2>
        <br />

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <label for="QImage">Question Image</label>
        <form action="<?php echo e(route('revision-questions.store')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group" class="scrolling-container"
                style="max-height: 750px; overflow-y: auto; border: 3px solid #000;">

                <input type="file" class="form-control" id="QImage" name="QImage" accept="image/*" required>
                <img id="image-preview" src="#" alt="Question Image"
                    style="display: none; max-width: 100%; height: auto;">
            </div>
            <label for="AImage">Answer Image</label>
            <div class="form-group" class="scrolling-container"
                style="max-height: 750px; overflow-y: auto; border: 3px solid #000;">

                <input type="file" class="form-control" id="AImage" name="AImage" accept="image/*" required>
                <img id="aImagePreview" src="#" alt="Answer Image"
                    style="display: none; max-width: 100%; height: auto;">
            </div>

            <div class="form-group">
                <label for="subject_id">Subject</label>
                <select class="form-control" id="subject_id" name="subject_id" required>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->SName); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="chapter_id">Chapter</label>
                <select class="form-control" id="chapter_id" name="chapter_id" required>

                </select>
            </div>

            <button class="btn btn-primary">Create Revision Question</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


    <script>
        function readURL(input, previewId) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#' + previewId).attr('src', e.target.result).show();
                };
                reader.readAsDataURL(input.files[0]);
            }
        }

        $('#QImage').change(function() {
            readURL(this, 'image-preview');
        });

        $('#AImage').change(function() {
            readURL(this, 'aImagePreview');
        });


        $('#subject_id').change(function() {
            var subjectId = $(this).val();
            updateChapters(subjectId);
        });


        function updateChapters(subjectId) {
            $.ajax({
                url: '/get-chapters/' + subjectId,
                method: 'GET',
                success: function(data) {

                    $('#chapter_id').empty();
                    $('#chapter_id').append($('<option>', {
                        value: '',
                        text: 'Select a Chapter'
                    }));
                    $.each(data, function(key, value) {
                        $('#chapter_id').append($('<option>', {
                            value: key,
                            text: value
                        }));
                    });
                }
            });
        }


        var initialSubjectId = $('#subject_id').val();
        updateChapters(initialSubjectId);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/revision-questions/create.blade.php ENDPATH**/ ?>