<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>
        <div class="container mx-auto">
            <h1 class="my-4" style="font-weight:bold; font-size:18pt; text-align: center;">MCQ Self-Evaluation Result</h1>
            <br />

            <div class="mb-4" style="text-align: center;">
                <?php if($evaluationResult === 'strong'): ?>
                    <p>Congratulations! You are strong in this subject.</p>
                <?php else: ?>
                    <p style="font-weight:lighter">Keep practicing. You need improvement in this subject.</p>
                <?php endif; ?>
            </div>

            <div class="mb-4" style="text-align: center;">
                <p>Your Score: <?php echo e($score); ?> out of <?php echo e($totalQuestions); ?></p>
            </div>

            <div class="mb-4" style="text-align: center;">
                <a href="<?php echo e(route('usermodule.mcqEvaluationPage')); ?>"
                    class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded" style="margin-right: 10px">
                    Retake the Test
                </a>
                <a href="<?php echo e(route('home')); ?>" class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded">
                    Return to Dashboard
                </a>
            </div>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/usermodule/mcq_evaluation_result.blade.php ENDPATH**/ ?>