<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Admin Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <p class="font-bold text-2xl mb-4"><?php echo e(__('You are logged in as an Admin!')); ?></p>


                    <p class="text-lg text-gray-800 dark:text-gray-200">
                        You can perform the following tasks:
                    </p>


                    <div class="mt-4">
                        <ul>
                            <li>
                                <a href="<?php echo e(route('subjects.index')); ?>"
                                    class="text-blue-500 hover:text-blue-700 font-semibold">
                                    Manage Subjects
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('chapters.index')); ?>"
                                    class="text-blue-500 hover:text-blue-700 font-semibold">
                                    Manage Chapters
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('revision-questions.index')); ?>"
                                    class="text-blue-500 hover:text-blue-700 font-semibold">
                                    Manage Revision Questions
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('mcquestions.index')); ?>"
                                    class="text-blue-500 hover:text-blue-700 font-semibold">
                                    Manage Self-evaluation MCQ Questions
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/admin/adminhome.blade.php ENDPATH**/ ?>