

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Manage Chapters')); ?>

        </h2>
        <br />
        <div class="mb-3">
            <label for="subjectFilter">Filter by Subject:</label>
            <select id="subjectFilter" class="form-select" onchange="applyFilter()">
                <option value="">All Subjects</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->SName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br />
        <a href="<?php echo e(route('chapters.create')); ?>" class="btn btn-primary mb-3">Create New Chapter</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-3">Back to Dashboard</a>
        <br />
        <br />

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Chapter Name</th>
                    <th scope="col">Subject Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="chapter-row" data-subject-id="<?php echo e($chapter->subject->id); ?>">
                        <th scope="row"><?php echo e($chapter->id); ?></th>
                        <td><?php echo e($chapter->CName); ?></td>
                        <td><?php echo e($chapter->subject->SName); ?></td>
                        <td><?php echo e($chapter->CDescription); ?></td>
                        <td>
                            <a href="<?php echo e(route('chapters.show', $chapter->id)); ?>" class="btn btn-primary">View</a>
                            <a href="<?php echo e(route('chapters.edit', $chapter->id)); ?>" class="btn btn-warning">Edit</a>
                            <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($chapter->id); ?>')">Delete</button>
                            <form id="deleteForm-<?php echo e($chapter->id); ?>"
                                action="<?php echo e(route('chapters.destroy', $chapter->id)); ?>" method="POST"
                                style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        function confirmDelete(chapterId) {
            if (confirm('Are you sure you want to delete this chapter?')) {
                document.getElementById('deleteForm-' + chapterId).submit();
            }
        }

        function applyFilter() {
            const selectedSubjectId = document.getElementById('subjectFilter').value;
            const chapterRows = document.querySelectorAll('.chapter-row');

            chapterRows.forEach(row => {
                const rowSubjectId = row.getAttribute('data-subject-id');
                if (selectedSubjectId === '' || selectedSubjectId === rowSubjectId) {
                    row.style.display = 'table-row';
                } else {
                    row.style.display = 'none';
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/chapters/index.blade.php ENDPATH**/ ?>