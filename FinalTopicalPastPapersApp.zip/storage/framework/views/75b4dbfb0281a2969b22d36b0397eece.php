
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Revision Question Details')); ?>

        </h2>

        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Question Image</h3>
                <div class="scrolling-container" style="max-height: 500px; overflow-y: auto; border: 3px solid #000;">
                    <?php if(!empty($revisionQuestion->QImage)): ?>
                        <img src="<?php echo e(asset('storage/' . $revisionQuestion->QImage)); ?>" alt="Question Image"
                            style="max-width: 80%;">
                    <?php else: ?>
                        <p class="card-text">N/A</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Answer Image</h3>
                <div class="scrolling-container" style="max-height: 500px; overflow-y: auto; border: 3px solid #000;">
                    <?php if(!empty($revisionQuestion->AImage)): ?>
                        <img src="<?php echo e(asset('storage/' . $revisionQuestion->AImage)); ?>" alt="Answer Image"
                            style="max-width: 80%;">
                    <?php else: ?>
                        <p class="card-text">N/A</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Subject</h3>
                <p class="card-text"><?php echo e($revisionQuestion->chapter->subject->SName); ?></p>
            </div>
        </div>
        
        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Chapter</h3>
                <p class="card-text"><?php echo e($revisionQuestion->chapter->CName); ?></p>
            </div>
        </div>
        <a href="<?php echo e(route('revision-questions.index')); ?>" class="btn btn-primary mt-3">Back</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/revision-questions/show.blade.php ENDPATH**/ ?>