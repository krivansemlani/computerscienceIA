
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Edit Revision Question')); ?>


        </h2>
        <br />
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('revision-questions.update', $revisionQuestion->id)); ?>" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <label for="QImage">Question Image</label>
            <div class="form-group" class="scrolling-container"
                style="max-height: 750px; overflow-y: auto; border: 3px solid #000;">
                <input type="file" class="form-control" id="QImage" name="QImage" accept="image/*"
                    onchange="previewImage('QImage', 'image-preview')" style="padding: 10px 0;">
                <img id="image-preview" src="<?php echo e(asset('storage/' . $revisionQuestion->QImage)); ?>" alt="Question Image"
                    style="max-width: 100%; height: auto;">
            </div>

            <label for="AImage">Answer Image</label>

            <div class="form-group" class="scrolling-container"
                style="max-height: 750px; overflow-y: auto; border: 3px solid #000;">
                <input type="file" class="form-control" id="AImage" name="AImage" accept="image/*"
                    onchange="previewImage('AImage', 'aImagePreview')" style="padding: 10px 0;">
                <img id="aImagePreview" src="<?php echo e(asset('storage/' . $revisionQuestion->AImage)); ?>" alt="Answer Image"
                    style="max-width: 100%; height: auto;">
            </div>

            <div class="form-group">
                <label for="subject_id">Subject</label>
                <select class="form-control" id="subject_id" name="subject_id" required>
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>"
                            <?php echo e($subject->id == $revisionQuestion->chapter->subject->id ? 'selected' : ''); ?>>
                            <?php echo e($subject->SName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="chapter_id">Chapter</label>
                <select class="form-control" id="chapter_id" name="chapter_id" required>
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chapter->id); ?>"
                            <?php echo e($chapter->id == $revisionQuestion->chapter->id ? 'selected' : ''); ?>>
                            <?php echo e($chapter->CName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>


            <button class="btn btn-primary">Update Revision Question</button>
        </form>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script>
        function previewImage(inputId, previewId) {
            var input = document.getElementById(inputId);
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById(previewId).src = e.target.result;
                };
                reader.readAsDataURL(input.files[0]);
            }
        }


        window.addEventListener('load', function() {
            previewImage('QImage', 'image-preview');
            previewImage('AImage', 'aImagePreview');
        });


        $('#subject_id').change(function() {
            var subjectId = $(this).val();
            updateChapters(subjectId);
        });


        function updateChapters(subjectId) {
            $.ajax({
                url: '/get-chapters/' + subjectId,
                method: 'GET',
                success: function(data) {

                    $('#chapter_id').empty();
                    $('#chapter_id').append($('<option>', {
                        value: '',
                        text: 'Select a Chapter'
                    }));
                    $.each(data, function(key, value) {

                        var selected = key == <?php echo e($revisionQuestion->chapter->id); ?> ? 'selected' : '';
                        $('#chapter_id').append($('<option>', {
                            value: key,
                            text: value,
                            selected: selected
                        }));
                    });
                }
            });
        }


        var initialSubjectId = $('#subject_id').val();
        updateChapters(initialSubjectId);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/revision-questions/edit.blade.php ENDPATH**/ ?>