

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1 class="mt-5">Subject Details</h1>

        <table class="table">
            <tbody>
                <tr>
                    <th scope="row">Subject Name</th>
                    <td><?php echo e($subject->SName); ?></td>
                </tr>
                <tr>
                    <th scope="row">Description</th>
                    <td><?php echo e($subject->SDescription); ?></td>
                </tr>
            </tbody>
        </table>
        <br />

        <a href="<?php echo e(route('subjects.index')); ?>" class="btn btn-primary">Back to Subjects</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/subjects/show.blade.php ENDPATH**/ ?>