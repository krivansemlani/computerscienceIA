

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Manage Subjects')); ?>

        </h2>
        <br />
        <a href="<?php echo e(route('subjects.create')); ?>" class="btn btn-primary mb-3">Create New Subject</a>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-3">Back to Dashboard</a>
        <br />
        <br />
        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Subject Name</th>
                    <th scope="col">Description</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($subject->id); ?></th>
                        <td><?php echo e($subject->SName); ?></td>
                        <td><?php echo e($subject->SDescription); ?></td>
                        <td>
                            <a href="<?php echo e(route('subjects.show', $subject->id)); ?>" class="btn btn-primary">View</a>
                            <a href="<?php echo e(route('subjects.edit', $subject->id)); ?>" class="btn btn-warning">Edit</a>
                            <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($subject->id); ?>')">Delete</button>
                            <form id="deleteForm-<?php echo e($subject->id); ?>"
                                action="<?php echo e(route('subjects.destroy', $subject->id)); ?>" method="POST"
                                style="display: none;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script>
        function confirmDelete(subjectId) {
            if (confirm('Are you sure you want to delete this subject and all its corresponding chapters and questions?')) {

                document.getElementById('deleteForm-' + subjectId).submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/subjects/index.blade.php ENDPATH**/ ?>