

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Chapter Details')); ?>



        </h2>
        <br />
        <table class="table">
            <tbody>
                <tr>
                    <th scope="row">Chapter Name</th>
                    <td><?php echo e($chapter->CName); ?></td>
                </tr>
                <tr>
                    <th scope="row">Description</th>
                    <td><?php echo e($chapter->CDescription); ?></td>
                </tr>
                <tr>
                    <th scope="row">Subject</th>
                    <td><?php echo e($chapter->subject->SName); ?></td>
                </tr>
            </tbody>
        </table>
        <br />

        <a href="<?php echo e(route('chapters.index')); ?>" class="btn btn-primary">Back to Chapters</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/chapters/show.blade.php ENDPATH**/ ?>