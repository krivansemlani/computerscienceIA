
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Manage MCQs')); ?>

        </h2>
        <br />
        <div class="mb-3">
            <label for="subjectFilter">Filter by Subject:</label>
            <select id="subjectFilter" class="form-select" onchange="applyFilter()">
                <option value="">All Subjects</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->SName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br />
        <div class="mb-3">
            <label for="chapterFilter">Filter by Chapter:</label>
            <select id="chapterFilter" class="form-select" onchange="applyFilter()">
                <option value="">All Chapters</option>
                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($chapter->id); ?>"><?php echo e($chapter->CName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br />
        <a href="<?php echo e(route('mcquestions.create')); ?>" class="btn btn-primary mb-3">Create New Question</a>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-3">Back to Dashboard</a>
        <br />
        <br />

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Question</th>
                    <th scope="col">Options</th>
                    <th scope="col">Answer</th>
                    <th style="padding-right: 20px;" scope="col">Subject</th>
                    <th scope="col">Chapter</th>
                    <th scope="col">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mcquestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mcquestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="mcquestions-row" data-subject-id="<?php echo e($mcquestion->chapter->subject->id); ?>"
                        data-chapter-id="<?php echo e($mcquestion->chapter->id); ?>">
                        <th scope="row"><?php echo e($mcquestion->id); ?></th>
                        <td><img src="<?php echo e(asset('storage/' . $mcquestion->QImage)); ?>" alt="Question Image" width="100">
                        </td>
                        <td>
                            <ul>
                                <li><?php echo e($mcquestion->Option1); ?></li>
                                <li><?php echo e($mcquestion->Option2); ?></li>
                                <li><?php echo e($mcquestion->Option3); ?></li>
                                <li><?php echo e($mcquestion->Option4); ?></li>
                            </ul>
                        </td>
                        <td style="padding-right: 20px;"><?php echo e($mcquestion->Answer); ?></td>

                        <td style="padding-right: 20px;"><?php echo e($mcquestion->chapter->subject->SName); ?></td>
                        <td style="padding-right: 20px;"><?php echo e($mcquestion->chapter->CName); ?></td>
                        <td>
                            <a href="<?php echo e(route('mcquestions.show', $mcquestion->id)); ?>" class="btn btn-primary">View</a>
                            <a href="<?php echo e(route('mcquestions.edit', $mcquestion->id)); ?>" class="btn btn-warning">Edit</a>
                            <button class="btn btn-danger" onclick="confirmDelete('<?php echo e($mcquestion->id); ?>')">Delete</button>
                            <form id="deleteForm<?php echo e($mcquestion->id); ?>"
                                action="<?php echo e(route('mcquestions.destroy', $mcquestion->id)); ?>" method="POST"
                                class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>
        function applyFilter() {
            const selectedSubjectId = document.getElementById('subjectFilter').value;
            const selectedChapterId = document.getElementById('chapterFilter').value;
            const mcquestionsRows = document.querySelectorAll('.mcquestions-row');

            mcquestionsRows.forEach(row => {
                const rowSubjectId = row.getAttribute('data-subject-id');
                const rowChapterId = row.getAttribute('data-chapter-id');

                const subjectFilterMatch = selectedSubjectId === '' || selectedSubjectId === rowSubjectId;
                const chapterFilterMatch = selectedChapterId === '' || selectedChapterId === rowChapterId;

                if (subjectFilterMatch && chapterFilterMatch) {
                    row.style.display = 'table-row';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function confirmDelete(questionId) {
            if (confirm('Are you sure you want to delete this question?')) {
                document.getElementById('deleteForm' + questionId).submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/mcquestions/index.blade.php ENDPATH**/ ?>