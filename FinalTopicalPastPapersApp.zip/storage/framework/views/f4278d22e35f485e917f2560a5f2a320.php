<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startSection('content'); ?>
        <div class="container">
            <h1 class="my-4" style="font-weight: bold; font-size:18pt">MCQ Self-Evaluation</h1>
            <br />

            <p>Currently taking a test on: <strong><?php echo e($selectedSubject->SName); ?></strong> -
                <strong><?php echo e($selectedChapter->CName); ?></strong></p>

            <form method="POST" action="<?php echo e(route('usermodule.submitEvaluation')); ?>">
                <?php echo csrf_field(); ?>

                <?php $__currentLoopData = $selectedQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-4" style="display: flex;">
                        <div class="question-container"
                            style="border: 1px solid #000000; max-height: 500px; overflow-y: auto; padding: 10px; flex: 1;">
                            <p><img class="question-image" src="<?php echo e(asset('storage/' . $question->QImage)); ?>"
                                    alt="Question Image"></p>
                        </div>
                        <div class="panel"
                            style="border: 1px solid #ccc; max-height: 500px; overflow-y: auto; padding: 10px; flex: 1; margin-left: 10px;">
                            <div class="form-check" style="margin-bottom: 8px;">
                                <input class="form-check-input" type="radio" name="answers[<?php echo e($question->id); ?>]"
                                    value="option1" id="answers[<?php echo e($question->id); ?>]_option1">
                                <label class="form-check-label" for="answers[<?php echo e($question->id); ?>]_option1">
                                    <?php echo e($question->Option1); ?>

                                </label>
                            </div>
                            <div class="form-check" style="margin-bottom: 8px;">
                                <input class="form-check-input" type="radio" name="answers[<?php echo e($question->id); ?>]"
                                    value="option2" id="answers[<?php echo e($question->id); ?>]_option2">
                                <label class="form-check-label" for="answers[<?php echo e($question->id); ?>]_option2">
                                    <?php echo e($question->Option2); ?>

                                </label>
                            </div>
                            <div class="form-check" style="margin-bottom: 8px;">
                                <input class="form-check-input" type="radio" name="answers[<?php echo e($question->id); ?>]"
                                    value="option3" id="answers[<?php echo e($question->id); ?>]_option3">
                                <label class="form-check-label" for="answers[<?php echo e($question->id); ?>]_option3">
                                    <?php echo e($question->Option3); ?>

                                </label>
                            </div>
                            <div class="form-check" style="margin-bottom: 8px;">
                                <input class="form-check-input" type="radio" name="answers[<?php echo e($question->id); ?>]"
                                    value="option4" id="answers[<?php echo e($question->id); ?>]_option4">
                                <label class="form-check-label" for="answers[<?php echo e($question->id); ?>]_option4">
                                    <?php echo e($question->Option4); ?>

                                </label>
                            </div>
                            <div class="annotation-box"
                                style="border: 1px solid #ccc; overflow-y: auto; padding: 10px; margin-top: 10px;">
                                <label for="annotation">Rough Work or Annotations</label>
                                <textarea id="annotation" name="answers_annotation[<?php echo e($question->id); ?>]" rows="6" style="width: 100%;"></textarea>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="mb-4 flex justify-center">
                    <button type="submit"
                        style="background-color: #3490dc; color: #ffffff; font-weight: bold; padding: 10px 20px; border-radius: 8px; cursor: pointer;">
                        Submit Answers
                    </button>
                </div>


            </form>
        </div>

     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/usermodule/mcq_evaluation_test.blade.php ENDPATH**/ ?>