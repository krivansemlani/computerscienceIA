<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Manage Revision Questions')); ?>

        </h2>
        <br />
        <div class="mb-3">
            <label for="subjectFilter">Filter by Subject:</label>
            <select id="subjectFilter" class="form-select" onchange="applyFilter()">
                <option value="">All Subjects</option>
                <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->SName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br />
        <div class="mb-3">
            <label for="chapterFilter">Filter by Chapter:</label>
            <select id="chapterFilter" class="form-select" onchange="applyFilter()">
                <option value="">All Chapters</option>
                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($chapter->id); ?>"><?php echo e($chapter->CName); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <br />
        <a href="<?php echo e(route('revision-questions.create')); ?>" class="btn btn-primary mb-3">Create New Revision Question</a>

        <?php if(session('success')): ?>
            <div class="mt-4">
                <div class="font-medium text-green-600"><?php echo e(session('success')); ?></div>
            </div>
        <?php endif; ?>
        <a href="<?php echo e(route('home')); ?>" class="btn btn-secondary mb-3">Back to Dashboard</a>
        <br />
        <br />


        <table class="table">
            <thead>
                <tr>
                    <th style="padding-right: 20px;">ID</th>
                    <th style="padding-right: 20px;">Question Image</th>
                    <th style="padding-right: 20px;">Answer Image</th>
                    <th style="padding-right: 20px;">Chapter</th>
                    <th style="padding-right: 20px;">Subject</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $revisionQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $revisionQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="revision-question-row" data-subject-id="<?php echo e($revisionQuestion->chapter->subject->id); ?>"
                        data-chapter-id="<?php echo e($revisionQuestion->chapter->id); ?>">
                        <td style="padding-right: 20px;"><?php echo e($revisionQuestion->id); ?></td>
                        <td style="padding-right: 20px;">
                            <?php if(!empty($revisionQuestion->QImage)): ?>
                                <img src="<?php echo e(asset('storage/' . $revisionQuestion->QImage)); ?>" alt="Question Image"
                                    width="100">
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td style="padding-right: 20px;">
                            <?php if(!empty($revisionQuestion->AImage)): ?>
                                <img src="<?php echo e(asset('storage/' . $revisionQuestion->AImage)); ?>" alt="Answer Image"
                                    width="100">
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td style="padding-right: 20px;"><?php echo e($revisionQuestion->chapter->CName); ?></td>
                        <td style="padding-right: 20px;"><?php echo e($revisionQuestion->chapter->subject->SName); ?></td>
                        <td>
                            <a href="<?php echo e(route('revision-questions.show', $revisionQuestion->id)); ?>"
                                class="btn btn-primary">View</a>
                            <a href="<?php echo e(route('revision-questions.edit', $revisionQuestion->id)); ?>"
                                class="btn btn-primary">Edit</a>
                            <button class="btn btn-danger"
                                onclick="confirmDelete('<?php echo e($revisionQuestion->id); ?>')">Delete</button>
                            <form id="deleteForm<?php echo e($revisionQuestion->id); ?>"
                                action="<?php echo e(route('revision-questions.destroy', $revisionQuestion->id)); ?>" method="POST"
                                class="inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <script>
        function applyFilter() {
            const selectedSubjectId = document.getElementById('subjectFilter').value;
            const selectedChapterId = document.getElementById('chapterFilter').value;
            const revisionQuestionRows = document.querySelectorAll('.revision-question-row');

            revisionQuestionRows.forEach(row => {
                const rowSubjectId = row.getAttribute('data-subject-id');
                const rowChapterId = row.getAttribute('data-chapter-id');

                const subjectFilterMatch = selectedSubjectId === '' || selectedSubjectId === rowSubjectId;
                const chapterFilterMatch = selectedChapterId === '' || selectedChapterId === rowChapterId;

                if (subjectFilterMatch && chapterFilterMatch) {
                    row.style.display = 'table-row';
                } else {
                    row.style.display = 'none';
                }
            });
        }

        function confirmDelete(questionId) {
            if (confirm('Are you sure you want to delete this question?')) {
                document.getElementById('deleteForm' + questionId).submit();
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/revision-questions/index.blade.php ENDPATH**/ ?>