<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('MCQ Self-Evaluation')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="container mx-auto mt-4 p-4">

        <form method="POST" action="<?php echo e(route('usermodule.startEvaluation')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="subject">Select Subject</label>
                <select class="form-control" id="subject" name="subject_id" style="width: 100%;">
                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($subject->id); ?>"
                            <?php echo e($subject->id == $selectedSubject ? 'selected' : ''); ?>>
                            <?php echo e($subject->SName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="chapter">Select Chapter</label>
                <select class="form-control" id="chapter" name="chapter_id" style="width: 100%;">
                    <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($chapter->id); ?>"
                            <?php echo e($chapter->id == $selectedChapter ? 'selected' : ''); ?>>
                            <?php echo e($chapter->CName); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-4">
                <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                    Start Evaluation
                </button>
            </div>
        </form>
    </div>

    <script>
        // Function to update chapters based on the selected subject
        function updateChapters(subjectId) {
            $.ajax({
                url: '/get-chapters/' + subjectId,
                method: 'GET',
                success: function(data) {
                    // Update the chapters dropdown with the fetched chapters
                    $('#chapter').empty();
                    $('#chapter').append($('<option>', {
                        value: '',
                        text: 'Select a Chapter'
                    }));
                    $.each(data, function(key, value) {
                        $('#chapter').append($('<option>', {
                            value: key,
                            text: value
                        }));
                    });
                }
            });
        }

        // Initialize chapters based on the selected subject
        var initialSubjectId = $('#subject').val();
        updateChapters(initialSubjectId);

        // When the subject dropdown changes, update the chapters
        $('#subject').change(function() {
            var subjectId = $(this).val();
            updateChapters(subjectId);
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>
<?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/usermodule/mcq_evaluation.blade.php ENDPATH**/ ?>