
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('MCQ Details')); ?>

        </h2>
        <br />
        <div class="card">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Question Image</h3>

                <div class="scrolling-container" style="max-height: 500px; overflow-y: auto;  border: 3px solid #000;">
                    <img src="<?php echo e(asset('storage/' . $mcquestion->QImage)); ?>" alt="Question Image" width="750">
                </div>
            </div>
            <br />
            <ul class="list-group list-group-flush">
                <li class="list-group-item">Option 1: <?php echo e($mcquestion->Option1); ?></li>
                <li class="list-group-item">Option 2: <?php echo e($mcquestion->Option2); ?></li>
                <li class="list-group-item">Option 3: <?php echo e($mcquestion->Option3); ?></li>
                <li class="list-group-item">Option 4: <?php echo e($mcquestion->Option4); ?></li>
                <li class="list-group-item">Answer: <?php echo e($mcquestion->Answer); ?></li>
            </ul>
        </div>
        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Subject</h3>
                <p class="card-text"><?php echo e($mcquestion->chapter->subject->SName); ?></p>
            </div>
        </div>
        <div class="card mt-3">
            <div class="card-body">
                <h3 class="card-title" style="font-weight: bold;">Chapter</h3>
                <p class="card-text"><?php echo e($mcquestion->chapter->CName); ?></p>
            </div>
        </div>
        <a href="<?php echo e(route('mcquestions.index')); ?>" class="btn btn-primary mt-3">Back to MCQuestion List</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/mcquestions/show.blade.php ENDPATH**/ ?>