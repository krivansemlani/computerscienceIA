<?php if (isset($component)) { $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb = $component; } ?>
<?php $component = App\View\Components\DashboardLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('dashboard-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\DashboardLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php $__env->startSection('content'); ?>
        <div class="container mx-auto mt-8 p-8 bg-white rounded-lg shadow-lg" style="margin: 20px; padding: 20px;">
            <h1 class="text-3xl font-semibold mb-6">MCQ Self-Evaluation</h1>
            <form method="POST" action="<?php echo e(route('usermodule.startEvaluation')); ?>" class="max-w-md mx-auto">
                <?php echo csrf_field(); ?>
                <div class="mb-6">
                    <label for="subject" class="block text-gray-700 text-sm font-bold mb-2">Select Subject:</label>
                    <select name="subject_id" id="subject" class="w-full p-3 border border-gray-300 rounded" required>
                        <option value="" disabled selected>Select a Subject</option>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subject->id); ?>"><?php echo e($subject->SName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-6">
                    <label for="chapter" class="block text-gray-700 text-sm font-bold mb-2">Select Chapter:</label>
                    <select name="chapter_id" id="chapter" class="w-full p-3 border border-gray-300 rounded" required>
                        <option value="" disabled selected>Select a Chapter</option>
                    </select>
                </div>
                <div class="mb-6">
                    <div class="mb-4 flex justify-center">
                        <button type="submit" id="startEvaluationBtn" disabled
                            style="background-color: #3490dc; color: #ffffff; font-weight: bold; padding: 10px 20px; border-radius: 8px; cursor: pointer;">
                            Start Evaluation
                        </button>
                    </div>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb)): ?>
<?php $component = $__componentOriginal0de143e5b61900e6d7b990ac144ae3fb; ?>
<?php unset($__componentOriginal0de143e5b61900e6d7b990ac144ae3fb); ?>
<?php endif; ?>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function updateChapters(subjectId) {
            $.ajax({
                url: '/get-chapters/' + subjectId,
                method: 'GET',
                success: function(data) {

                    $('#chapter').empty();
                    $('#chapter').append($('<option>', {
                        value: '',
                        text: 'Select a Chapter',
                        disabled: true,
                        selected: true
                    }));
                    $.each(data, function(key, value) {
                        $('#chapter').append($('<option>', {
                            value: key,
                            text: value
                        }));
                    });
                }
            });
        }
        var initialSubjectId = $('#subject').val();
        updateChapters(initialSubjectId);
        $('#subject').change(function() {
            var subjectId = $(this).val();
            updateChapters(subjectId);
        });
        $('form').on('input change', function() {
            $('#startEvaluationBtn').prop('disabled', !this.checkValidity());
        });
    </script>
<?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/usermodule/mcqEvaluationPage.blade.php ENDPATH**/ ?>