

<?php $__env->startSection('content'); ?>
    <div class='container'>
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Create new subject')); ?>

        </h2>
        <br />

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('subjects.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="SName">Subject Name</label>
                <input type="text" class="form-control" id="SName" name="SName" required>
            </div>
            <div class="form-group">
                <label for="SDescription">Description</label>
                <textarea class="form-control" id="SDescription" name="SDescription" rows="3"></textarea>
            </div>
            <button class="btn btn-primary">Create Subject</button>
        </form>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.subject-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sushil\Desktop\FinalTopicalPastPapersApp\resources\views/subjects/create.blade.php ENDPATH**/ ?>